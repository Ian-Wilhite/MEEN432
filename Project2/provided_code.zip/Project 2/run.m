clc;
clear;
init;
gentrack;
animate;