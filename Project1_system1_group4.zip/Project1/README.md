# MEEN 432 - Automotive Engineering

## TEAM 4

 - Ian Wilhite
 - Dalys Guajardo
 - Juan Lopez

## Running the code 

The plots are made by running project1.m

in Matlab, you can open the folder and run it. 

Through VSCode with the CLI, you can run

```
matlab -batch "project1"
```
